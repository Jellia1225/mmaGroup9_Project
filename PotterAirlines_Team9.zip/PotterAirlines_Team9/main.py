from search_flight import search_flights
from booking import book_flight
import subprocess

# Runs other scripts and waits for it to finish
subprocess.run(["python", "flight_class.py"])
subprocess.run(["python", "database.py"])
subprocess.run(["python", "database.py"])
subprocess.run(["python", "database.py"])

results = search_flights()

if results:
    for flight in results:
       print(flight)

    flight_id = input(
       "Enter the Flight ID to book (or press Ener to cancel):"
    ).strip()

    if flight_id:
       departure_date = input(
          "Enter the Departure Date (YYYY-MM-DD)(or press Enter to cancel):"
        ).strip()
       book_flight(flight_id, departure_date)
       
    else:
       print("Booking Cancelled")