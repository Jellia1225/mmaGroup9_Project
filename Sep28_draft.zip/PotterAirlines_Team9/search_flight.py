import sqlite3
from datetime import date
import pandas as pd
from pricing import calculate_prices

DB_PATH = "potter_airlines.db"

def search_flights():
    origin = input("Please Enter Origin: ")
    destination = input("Please Enter Destination: ")
    departure_date = input(
        f"Departure Date (YYYY-MM-DD, press Enter for {date.today()}): "
    ).strip()

    if departure_date == "":
        departure_date = str(date.today())
    max_price = input("Maximum Price (optional): ")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    query = """
    SELECT
        flight_id,
        origin,
        destination,
        departure_date,
        base_fare,
        seats_remaining,
        capacity,
        route_demand,
        season,
        is_weekend
    FROM flights
    WHERE LOWER(origin) = LOWER(?)
        AND LOWER(destination) = LOWER(?)

    """
    params = [origin, destination]

    if departure_date.strip():
        query += " AND departure_date >= ?"
        params.append(departure_date)

    if max_price.strip():
        query += " AND base_fare <= ?"
        params.append(float(max_price))

    cursor.execute(query, params)

    flight_results = cursor.fetchall()

    conn.close()

    if not flight_results:
        print("Sorry, no matching flights found.")
        return []

    priced_flights = calculate_prices(flight_results)

    return priced_flights
