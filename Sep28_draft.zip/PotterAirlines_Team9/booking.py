import sqlite3

DB_PATH = "potter_airlines.db"

def book_flight(flight_id, departure_date):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    ticket_number = int(input("How many tickets would you like to book? "))

    cursor.execute("""
        SELECT seats_remaining
        FROM flights
        WHERE flight_id = ?
          AND departure_date = ?
    """, (flight_id, departure_date))

    seats_remaining = cursor.fetchone()[0]

    if seats_remaining == 0:
        print("Sorry, this flight is fully booked.")
        conn.close()
        return

    if seats_remaining < ticket_number:
        print(f"Sorry, only {seats_remaining} seat(s) are available.")
        conn.close()
        return

    cursor.execute("""
        UPDATE flights
        SET seats_remaining = seats_remaining - ?
        WHERE flight_id = ?
          AND departure_date = ?
    """, (ticket_number, flight_id, departure_date))

    conn.commit()
    conn.close()

    print("Booking successful!")