
from datetime import date

# according to the pricing model file
# we have time factor, demand factor, capacity factor
#       seasonal factor and weekend factor



def calculate_prices(flight_results):

    # set the min price and max price
    MIN_FARE = 200
    MAX_FARE = 600

    priced_flights = []

    for flight in flight_results:

        departure_date = flight[3]
        base_fare = flight[4]
        seats_remaining = flight[5]
        capacity = flight[6]
        route_demand = flight[7]
        season = flight[8]
        is_weekend = flight[9]

        # --- time factor ---
        days_until_departure = (
            date.fromisoformat(departure_date) - date.today()       
        ).days

        if days_until_departure == 0:
            time_factor = 1.45
        elif days_until_departure <= 7:
            time_factor = 1.25
        elif days_until_departure <= 14:
            time_factor = 1.18
        elif days_until_departure <= 30:
            time_factor = 1.08
        else:
            time_factor = 0.95

        # --- demand factor ---
        if route_demand < 0.40:
            demand_factor = 0.90
        elif route_demand <= 0.70:
            demand_factor = 1.00
        else:
            demand_factor = 1.20

        # --- capacity factor ---
        load_factor = 1 - (seats_remaining / capacity)

        if load_factor < 0.5:
            capacity_factor = 0.9
        elif load_factor < 0.80:
            capacity_factor = 1.00
        elif load_factor < 0.90:
            capacity_factor = 1.15
        else:
            capacity_factor = 1.30

        # --- seasonal factor ---
        if season == "Vacation":
            season_factor = 1.15
        else:
            season_factor = 1.00

        # --- weekend factor ---
        if is_weekend == False:
            weekend_factor = 1.00
        else:
            weekend_factor = 1.10

        adj_price = base_fare * time_factor * demand_factor * capacity_factor * season_factor * weekend_factor

        final_price = max(
            MIN_FARE, 
            min(MAX_FARE, round(adj_price, 2))
        )

        priced_flights.append((
                flight[0],      # flight_id
                flight[1],      # origin
                flight[2],      # destination
                flight[3],      # departure_date
                final_price
            ))

    return priced_flights
    